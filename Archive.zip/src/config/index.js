export const API_URL = process?.env?.VITE_API_URL || "http://localhost:3000";
